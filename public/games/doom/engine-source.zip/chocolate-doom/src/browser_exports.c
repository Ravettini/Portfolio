//
// Browser-only exports for pausing and resuming the Emscripten main loop.
//

#include "config.h"
#include "i_video.h"

#ifdef EMSCRIPTEN

#include <emscripten.h>
#include <SDL.h>
void RAV_ReleaseInput(void);

EMSCRIPTEN_KEEPALIVE void DB_PauseMainLoop(void)
{
    RAV_ReleaseInput();
    SDL_PauseAudio(1);
    emscripten_pause_main_loop();
}

EMSCRIPTEN_KEEPALIVE void DB_ResumeMainLoop(void)
{
    SDL_PauseAudio(0);
    emscripten_resume_main_loop();
}

#else

void DB_PauseMainLoop(void)
{
}

void DB_ResumeMainLoop(void)
{
}

#endif
